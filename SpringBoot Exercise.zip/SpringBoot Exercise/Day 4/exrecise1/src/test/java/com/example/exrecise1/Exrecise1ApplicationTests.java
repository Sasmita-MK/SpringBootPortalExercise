package com.example.exrecise1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exrecise1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

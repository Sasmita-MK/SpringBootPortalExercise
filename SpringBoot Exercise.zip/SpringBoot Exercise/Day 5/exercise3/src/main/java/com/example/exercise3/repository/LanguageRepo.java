package com.example.exercise3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.exercise3.model.Language;


public interface LanguageRepo extends JpaRepository<Language,Integer>{
    
}


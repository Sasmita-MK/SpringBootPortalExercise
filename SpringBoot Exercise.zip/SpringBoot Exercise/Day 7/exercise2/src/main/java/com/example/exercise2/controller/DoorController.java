package com.example.exercise2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.exercise2.model.Door;
import com.example.exercise2.service.DoorService;


@RestController
public class DoorController {
    @Autowired
    private final DoorService ds;

    public DoorController(DoorService ds) {
        this.ds = ds;
    }
    @PostMapping("/api/door")
    public ResponseEntity<Door> create(Door d)
    {
        d.setLocation("Main Entrance");
        return new ResponseEntity<>(ds.create(d),HttpStatus.CREATED);
    }
    @GetMapping("/api/door")
    public ResponseEntity<List<Door>> getAll()
    {
        return new ResponseEntity<>(ds.getAll(),HttpStatus.OK);
    }
    @GetMapping("/api/door/{doorId}")
    public ResponseEntity<Door> getById(@PathVariable int id)
    {
        return new ResponseEntity<>(ds.getById(id),HttpStatus.OK);
    }
    @GetMapping("/api/door/accesstype/{accessType}")
    public ResponseEntity<List<Door>> filterByAccessType(@RequestParam(defaultValue = "Restricted") String accessType)
    {
        return new ResponseEntity<>(ds.filterByAccessType(accessType),HttpStatus.OK);
    }
}

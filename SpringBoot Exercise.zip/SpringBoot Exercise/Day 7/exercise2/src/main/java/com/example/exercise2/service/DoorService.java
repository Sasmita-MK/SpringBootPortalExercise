package com.example.exercise2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.exercise2.model.Door;
import com.example.exercise2.repository.DoorRepo;



@Service
public class DoorService {
    @Autowired
    private final DoorRepo dr;

    public DoorService(DoorRepo dr) {
        this.dr = dr;
    }
    public Door create(Door d)
    {
        return dr.save(d);
    }
    public List<Door> getAll()
    {
        return dr.findAll();
    }
    public Door getById(int id)
    {
        return dr.findById(id).orElse(null);
    }
    public List<Door> filterByAccessType(String accessType)
    {
        return dr.findByAccessType(accessType);
    }
    
}

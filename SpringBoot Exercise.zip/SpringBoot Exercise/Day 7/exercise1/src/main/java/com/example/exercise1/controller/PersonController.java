package com.example.exercise1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.exercise1.model.Person;
import com.example.exercise1.service.PersonService;



@RestController
public class PersonController {
    @Autowired
    private final PersonService ps;

    public PersonController(PersonService ps) {
        this.ps = ps;
    }
    @PostMapping("/api/person")
    public ResponseEntity<Person> create(@RequestBody Person p)
    {
        return new ResponseEntity<>(ps.create(p),HttpStatus.CREATED);
    }
    @GetMapping("/api/person")
    public ResponseEntity<List<Person>> getAll()
    {
        return new ResponseEntity<>(ps.getAll(),HttpStatus.OK);
    }
    @GetMapping("/api/person/byAge")
    public ResponseEntity<List<Person>> getByAge(@RequestParam(defaultValue = "30") int age)
    {
        return new ResponseEntity<>(ps.filterByAge(age),HttpStatus.OK);
    }

}


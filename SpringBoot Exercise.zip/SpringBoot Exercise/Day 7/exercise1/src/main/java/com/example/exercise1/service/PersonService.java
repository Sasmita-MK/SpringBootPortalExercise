package com.example.exercise1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.exercise1.model.Person;
import com.example.exercise1.repository.PersonRepo;



@Service
public class PersonService {
    @Autowired
    private final PersonRepo pr;

    public PersonService(PersonRepo pr) {
        this.pr = pr;
    }
    public Person create(Person p)
    {
        return pr.save(p);
    }
    public List<Person> getAll()
    {
        return pr.findAll();
    }
    public List<Person> filterByAge(int age)
    {
        return pr.findByAge(age);
    }
}

package com.example.exercise4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exercise4ApplicationTests {

	@Test
	void contextLoads() {
	}

}

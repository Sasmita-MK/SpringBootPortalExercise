package com.example.exercise1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.exercise1.model.Person;
import com.example.exercise1.service.PersonService;


@RestController
public class PersonController {
    @Autowired
    private final PersonService ps;

    public PersonController(PersonService ps) {
        this.ps = ps;
    }
    @PostMapping("/person")
    public ResponseEntity<Person> create(Person p)
    {
        return new ResponseEntity<>(ps.create(p),HttpStatus.CREATED);
    }
    @GetMapping("/person/startsWithName/{value}")
    public ResponseEntity<List<String>> getByStart(@RequestParam(defaultValue = "R") String value)
    {
        return new ResponseEntity<>(ps.getStartName(value),HttpStatus.OK);
    }
    @GetMapping("/person/endsWithName/{value}")
    public ResponseEntity<List<String>> getByEnd(@RequestParam(defaultValue = "sh") String value)
    {
        return new ResponseEntity<>(ps.getEndName(value),HttpStatus.OK);
    }
}

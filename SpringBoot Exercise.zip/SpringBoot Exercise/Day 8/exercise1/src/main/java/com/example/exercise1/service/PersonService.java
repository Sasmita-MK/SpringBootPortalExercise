package com.example.exercise1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.exercise1.model.Person;
import com.example.exercise1.repository.PersonRepo;



@Service
public class PersonService {
    @Autowired
    private final PersonRepo pr;

    public PersonService(PersonRepo pr) {
        this.pr = pr;
    }
    public Person create(Person p)
    {
        return pr.save(p);
    }
    public List<String> getStartName(String start)
    {
        return pr.findNameStart(start);
    }
    public List<String> getEndName(String end)
    {
        return pr.findNameEnd(end);
    }

}


package com.example.exercise1.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.exercise1.model.Person;


@Repository
public interface PersonRepo extends JpaRepository<Person, Long> {
    @Query("select p.name from Person p where p.name like concat(:start,'%')")
    List<String> findNameStart(@Param("start") String start);

    @Query("select p.name from Person p where p.name like concat('%',:end)")
    List<String> findNameEnd(@Param("end") String end);
}


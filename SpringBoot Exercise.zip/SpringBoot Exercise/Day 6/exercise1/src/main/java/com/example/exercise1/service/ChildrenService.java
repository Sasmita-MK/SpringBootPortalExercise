package com.example.exercise1.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.exercise1.model.Children;
import com.example.exercise1.repository.ChildrenRepo;

@Service
public class ChildrenService {
    @Autowired
    private final ChildrenRepo cr;

    public ChildrenService(ChildrenRepo cr) {
        this.cr = cr;
    }
    public Children create(Children c)
    {
        try{
            return cr.save(c);
        }
        catch(Exception e)
        {
            return null;
        }
    }
    public List<Children> sortChildren(String field)
    {
        Sort s = Sort.by(field).ascending();
        return cr.findAll(s);
    }
    public List<Children> paginationChildren(int offset,int pageSize)
    {
        PageRequest p = PageRequest.of(offset,pageSize);
        Page<Children> c = cr.findAll(p);
        return c.getContent();
    }
    public List<Children> sortAndPagination(int offset,int pageSize,String field)
    {
        Sort s = Sort.by(field).ascending();
        PageRequest p = PageRequest.of(offset,pageSize,s);
        Page<Children> c = cr.findAll(p);
        return c.getContent();
    }
}


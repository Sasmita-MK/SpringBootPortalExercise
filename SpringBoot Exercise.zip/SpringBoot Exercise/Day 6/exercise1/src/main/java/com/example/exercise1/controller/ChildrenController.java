package com.example.exercise1.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.exercise1.model.Children;
import com.example.exercise1.service.ChildrenService;

@RestController
public class ChildrenController {
    @Autowired
    private final ChildrenService cs;

    public ChildrenController(ChildrenService cs) {
        this.cs = cs;
    }
    @PostMapping("/api/children")
    public ResponseEntity<Children> create(@RequestBody Children c)
    {
        Children c1 = cs.create(c);
        if(c1 != null)
        {
            return new ResponseEntity<>(c1,HttpStatus.CREATED);
        }
        else
        {
            return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/api/children/sortBy/{field}")
    public List<Children> sortChildren(@PathVariable String field)
    {
        return cs.sortChildren(field);
    }
    @GetMapping("/api/children/{offset}/{pagesize}")
    public List<Children> paginationChildren(@PathVariable int offset, @PathVariable int pageSize)
    {
        return cs.paginationChildren(offset, pageSize);
    }
    @GetMapping("/api/children/{offset}/{pagesize}/{field}")
    public ResponseEntity<List<Children>> paginationAndSorting(@PathVariable int offset, @PathVariable int pageSize, @PathVariable String field)
    {
        return new ResponseEntity<>(cs.sortAndPagination(offset,pageSize,field),HttpStatus.OK);
    }
}

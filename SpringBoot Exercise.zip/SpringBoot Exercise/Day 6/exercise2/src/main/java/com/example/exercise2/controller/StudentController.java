package com.example.exercise2.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.exercise2.model.Student;
import com.example.exercise2.service.StudentService;

@RestController
public class StudentController {
    @Autowired
    private final StudentService ss;

    public StudentController(StudentService ss) {
        this.ss = ss;
    }
    @PostMapping("/api/student")
    public ResponseEntity<Student> create(@RequestBody Student s)
    {
        return new ResponseEntity<>(ss.create(s),HttpStatus.CREATED);
    }
    @GetMapping("/api/student")
    public ResponseEntity<List<Student>> pagination(@RequestParam(defaultValue = "0") int offset, @RequestParam(defaultValue = "10") int pageSize)
    {
        return new ResponseEntity<>(ss.pagination(offset,pageSize),HttpStatus.OK);
    }
    @GetMapping("/api/student/sort")
    public ResponseEntity<List<Student>> paginationAndSorting(@RequestParam(defaultValue = "0") int offset, @RequestParam(defaultValue = "10") int pageSize, @RequestParam(defaultValue = "name") String field)
    {
        return new ResponseEntity<>(ss.paginationAndSorting(offset, pageSize, field),HttpStatus.OK);
    }

}

package com.example.exercise2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.exercise2.model.Student;
import com.example.exercise2.repository.StudentRepo;

@Service
public class StudentService {
    @Autowired
    private final StudentRepo sr;

    public StudentService(StudentRepo sr) {
        this.sr = sr;
    }
    public Student create(Student s)
    {
        return sr.save(s);
    }
    public List<Student> pagination(int offset, int pageSize)
    {
        PageRequest p = PageRequest.of(offset,pageSize);
        Page<Student> page = sr.findAll(p);
        return page.toList();
    }
    public List<Student> paginationAndSorting(int offset, int pageSize, String field)
    {
        Sort s = Sort.by(field).ascending();
        PageRequest p = PageRequest.of(offset,pageSize,s);
        Page<Student> page = sr.findAll(p);
        return page.toList();
    }

}
